CLASS_ID_MAP = {
    "site-nav": "a",
    "zz": "b",
    "xyz": "c",
    "sitenav-mobile": "d",
    "qwz": "e",
    "sitenav-pc": "f"
};