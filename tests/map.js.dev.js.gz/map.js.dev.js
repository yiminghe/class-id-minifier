CLASS_ID_MAP = {
    "site-nav": "site-nav",
    "zz": "zz",
    "xyz": "xyz",
    "sitenav-mobile": "sitenav-mobile",
    "qwz": "qwz",
    "sitenav-pc": "sitenav-pc"
};